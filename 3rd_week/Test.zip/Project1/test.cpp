#include "vec.h"

vector2D vadd(vector2D u, vector2D v);

void main()
{
	vector2D a, b;

	a = vector2D(1, 3);
	b = vector2D(4, 5);

	vector2D c = vadd(a, b);

	std::cout << "problem1:  " << c.x << ", " << c.y <<std::endl;
	system("pause");
}

vector2D vadd(vector2D u, vector2D v)
{
	return vector2D( u.x + v.x, u.y + v.y);
}